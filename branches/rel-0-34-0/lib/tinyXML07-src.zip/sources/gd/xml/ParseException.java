/*
 *  gd.xml package: classes for parsing XML documents
 *  Copyright (C) 1999  Tom Gibara <tom@srac.org>
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

package gd.xml;


/** Used to report errors which may occur during parsing.
 *  @author Tom Gibara
 */

public class ParseException extends Exception {


    /** Constructs an exception with a default description.
     */

    public ParseException() { super("unspecified error"); }


    /** Constructs an exception with the specified description.
     *  @param msg  a description of the exception created
     */

    public ParseException(String msg) { super(msg); }

}
