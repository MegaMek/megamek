Last updated April 4, 2003 by Suvarov454
Updated March 30, 2003 by Hopalong

Most infantry models should be in parentheses.

"Leg" infy is officially "Foot"
GDL standard is 3MP
Nighthawk stats from "tactics of duty" an lostech
Fixed some years and tried to make names easier to read

These are a list of avaible weapons:

Infantry Flamer
Infantry Laser
Infantry LRM
Infantry MG
Infantry Rifle
Infantry SRM
Infantry Inferno SRM

IS Infantry Laser
IS Infantry MG
IS Infantry Rifle
IS Infantry SRM
IS Infantry Flamer

// The following weapons only apply to support trooper of Kage squads.
IS Flamer
IS Small Laser
BA-Single Machine Gun

BA-Auto GL
BA-Magshot GR
BA-Machine Gun
BA-Flamer
BA-Small Laser
BA-IS Medium Laser
BA-IS ER Small Laser
BA-IS Medium Pulse Laser

Sloth Small Laser
Triple Machine Guns
Triple Small Lasers
Twin Small Pulse Lasers

SRM-2
BA-SRM2 Ammo
BA-SRM2 (one shot) Ammo
BA-Inferno SRM
BA-Inferno SRM Ammo
Fenrir SRM-4
Fenrir SRM-4 Ammo

BA-Twin Flamers
BA-Clan ER Small Laser
Advanced SRM-2
BA-Advanced SRM2 Ammo

LegAttack
SwarmMek
StopSwarm

BA-Boarding Claw
BA-Assault Claws
BA-Magnetic Clamp
Parafoil

BA-Fire Resistant Armor
Improved Stealth, 1/4/7 to hit
Basic Stealth, 0/3/6 to hit
Standard Stealth, 1/3/6 to hit
Mimetic Armor, 3/2/1/0 movement, 0/1/2/3 to hit

Minesweeper
Light TAG, 9 hexes
Beagle Active Probe
Single-Hex ECM
BA-Compact Narc, 5 hexes
BA-Compact Narc Ammo
BA-Mine Launcher
BA-Mine Launcher Ammo

If anyone gets a chance to make SRM1 and SRM3, MRM1-3, and LRM1-3, with 1 ammo equal to 1
round, also heavy and light MG's for clan, it would help with customs :)